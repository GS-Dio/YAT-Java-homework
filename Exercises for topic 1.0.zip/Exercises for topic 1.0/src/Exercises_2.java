import com.sun.security.jgss.GSSUtil;

import java.util.Scanner;

public class Exercises_2 {
  public static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
//        Exercises1();
//        Exercises2();
//        Exercises3();
//        Exercises4();
//        Exercises5();
        Exercises24();
    }
    public static void Exercises1() {
            System.out.println("Введите первую число:");
            int a = scanner.nextInt();

            System.out.println("Введите второе число:");
            int b = scanner.nextInt();

            if (a > b) {
                System.out.println(a + " это наибольшое число");
            } else if (b > a) {
                System.out.println(b + " это наибольшое число");

            }
        }
    public static void Exercises2(){
            System.out.println("Введите первую число:");
            int a = scanner.nextInt();

            System.out.println("Введите второе число:");
            int b = scanner.nextInt();

            System.out.println("Введите третъе число:");
            int c = scanner.nextInt();

            if (a > b && a > c) {
                System.out.println(a + " это наибольшое число");
            } else if (b > a && b > c) {
                System.out.println(b + " это наибольшое число");
            } else if (c > a && c > b) {
                System.out.println(c + " это наибольшое число");
            }
        }
    public static void Exercises3(){
        System.out.print("Введите число:");
        int a = scanner.nextInt();
        if(a > 0){
            System.out.println("Число положительное");
    }
        else if( a == 0) {
            System.out.println("Число равно нулю");
            }
        else if( a < 0) {
            System.out.println("Число равно отрецательное");
        }

    }
    public static void Exercises4(){
        System.out.print("Введите число:");
        int a = scanner.nextInt();
        if (a % 5 == 0 && a % 11 == 0) {
            System.out.println("Чилсо делиться на 5 и 11");
        }
         else
            System.out.println("Число не делиться на 5 и 11");

    }
    public static void Exercises5(){
        System.out.print("Введите число:");
        int a = scanner.nextInt();
        if (a % 2 == 0) {
            System.out.println("Число четное");
        }
        else
            System.out.println("Число нечетное");
    }
    public static void Exercises6(){
        System.out.print("Введите год и я скажу висакосный ли он: ");
        int a = scanner.nextInt();
        if ( a % 4 == 0 && a % 400 == 0 && a % 100 == 0) {
            System.out.println(a + " високосный год.");
        }  else  {
            System.out.println(a + " не високосный год.");
        }

    }
    public static void Exercises7(){
        System.out.print("Введите ссимвод,а скажу алфавтный ли он: ");
        char a = scanner.next().charAt(0);
        if ((a >= 'A' && a <= 'Z') || (a>= 'a' && a <= 'z')){
            System.out.println("Символ алфовитный");
        }else
            System.out.println("Символ не алфовитный");
    }
    public static void Exercises8(){
        System.out.print("Введите букву и я скажу гласный ли он или согластный: ");
        char a = scanner.next().charAt(0);
        if ((a >= 'A' && a <= 'Z') || (a>= 'a' && a <= 'z')){
            if(a == 'A' || a=='a' || a=='E' || a=='e' || a=='I' || a=='i'|| a=='O' || a=='o'||a=='U'||a=='u'|| a=='Y'|| a=='y') {
                System.out.println("Буква галастная");
            }
            else
                System.out.println("Буква согластная");
        }else
            System.out.println("Символ не алфовитный");
    }
    public static void Exercises9(){
        System.out.print("Введите ссимвод,а скажу алфавтный ли он: ");
        char a = scanner.next().charAt(0);
        if ((a >= 'A' && a <= 'Z') || (a>= 'a' && a <= 'z')){
            System.out.println("Символ алфовитный");
        }else if(a >='0' && a <='9') {
            System.out.println("Символ это цифра");
        }
        else
            System.out.println("Это спец символ");
    }
    public static void Exercises10(){
        System.out.print("Введите ссимвод,а прописной ли он: ");
        char a = scanner.next().charAt(0);
        if (a >= 'A' && a <= 'Z') {
            System.out.println("Символ прописной");
        }else if (a>= 'a' && a <= 'z')
            System.out.println("Символ строчный");
        else
            System.out.println("Cимвол не алфовитный");
    }
    public static void Exercises11(){
        //Программа написана для ноября
        System.out.println("Введите день а скажу какой дегь недели: ");
        int a = scanner.nextInt();
        switch (a % 7){
            case 1:
                System.out.println("Среда");
                break;
            case 2:
                System.out.println("Четверг");
                break;
            case 3:
                System.out.println("Пятница");
                break;
            case 4 :
                System.out.println("Субота");
                break;
            case 5:
                System.out.println("Воскоесенье");
                break;
            case 6:
                System.out.println("Понидельник");
                break;
            case 7:
                System.out.println("Вторник");
                break;
            default:
                System.out.println("Некорректный ввод");
        }
    }
    public static void Exercises12(){
        System.out.println("Введите номера месяца: ");
        int a = scanner.nextInt();
        switch (a) {
            case 1:
                System.out.println("Январь");
                break;
            case 2:
                System.out.println("Февраль");
                break;
            case 3:
                System.out.println("Март");
                break;
            case 4:
                System.out.println("Апрель");
                break;
            case 5:
                System.out.println("Май");
                break;
            case 6:
                System.out.println("Июнь");
                break;
            case 7:
                System.out.println("Июль");
                break;
            case 8:
                System.out.println("Август");
                break;
            case 9:
                System.out.println("Сентябрь");
                break;
            case 10:
                System.out.println("Октябрь");
                break;
            case 11:
                System.out.println("Ноябрь");
                break;
            case 12:
                System.out.println("Декабрь");
                break;
            default:
                System.out.println("Некорректный номер месяца");
        }

        }
    public static void Exercises13(){
        System.out.print("Введите напинал бонкноты: ");
        int a = scanner.nextInt();
        System.out.print("Введите количество бонкнот: ");
        int b = scanner.nextInt();
        System.out.println("Здесь " + (a*b) + " tenge");
    }
    public static void Exercises14(){
        int a = 5;
        int b = 5;
        int c = 2;
        if(a + b > c && a + c > b && b + c > a){
        System.out.println("Этот треугольник допустымый");
    }
        else
            System.out.println("Этот не треугольник допустымый");
    }
    public static void Exercises15(){
        int a = 5;
        int b = 5;
        int c = 2;
        if(a + b > c && a + c > b && b + c > a){
            System.out.println("Этот треугольник допустымый");
        }
        else
            System.out.println("Этот не треугольник допустымый");
    }
    public static void Exercises16(){
        int a = 12;
        int b = 12;
        int c = 12;
        if ((a+b) == (a+c) && c+b == c+a) {
            System.out.println("Равностороний треугольник");
        }
        else if (a + b > c && a + c > b && b + c > a) {
            System.out.println("Равнобедренный треугольник");
        }
        else if ((a+b) != (a+c) && c+b != c+a)
            System.out.println("Cкалярный треугольник");
    }
    public static void Exercises17() {
    } //несделан
    public static void Exercises18(){
        System.out.print("Укажите сегодняшний доход: ");
        int a = scanner.nextInt();
        System.out.print("Укажите сегодняшний расход: ");
        int b = scanner.nextInt();
        int c = a-b;
        if (c >= 0 )
            System.out.println("Сегодншняя прибыль: " + c );
        else
            System.out.println("Сегодняшний убыток: " + c);
    }
    public static void Exercises19(){
        System.out.print("Введите оценку по Физике: ");
        int a = scanner.nextInt();
        System.out.print("Введите оценку по Химий: ");
        int b = scanner.nextInt();
        System.out.print("Введите оценку по Биологий: ");
        int c = scanner.nextInt();
        System.out.print("Введите оценку по Матиматике: ");
        int d = scanner.nextInt();
        System.out.print("Введите оценку по Информатике: ");
        int e = scanner.nextInt();
        int F = (a+b+c+d+e)/5;
        if(F >= 90) {
            System.out.println("Оценка А");
        }
        else if(F >= 80) {
            System.out.println("Оценка B");
        }
        else if(F >= 70) {
            System.out.println("Оценка C");
        }
        else if(F >= 60) {
            System.out.println("Оценка D");
        }
        else if(F >= 50) {
            System.out.println("Оценка E");
        }
        else if(F >= 40) {
            System.out.println("Оценка F");
        }
        else
            System.out.println("Некорректный ввод");

    }
    public static void Exercises20(){
     int ZP = 10000;
     int HRA = ZP/100*20;
     int DA = ZP - HRA;
        System.out.println("HRA = "+HRA);
        System.out.println("DA = "+DA);
        int ZP2 = 20000;
        int HRA2 = ZP2/100*25;
        int DA2 = ZP/100*90;
        System.out.println("HRA2 = "+HRA2);
        System.out.println("DA2 = "+DA2);
        int ZP3 = 20000;
        int HRA3 = ZP2/100*30;
        int DA3 = ZP/100*95;
        System.out.println("HRA3 = "+HRA3);
        System.out.println("DA3 = "+DA3);
    }
    public static void Exercises21(){
        System.out.print("Введите единицы использовонной электроэнергий:" );
     int a = scanner.nextInt(); // единици электричества
     double chet = 0;
      if(a<=50) {
          chet = a * 0.50;
      } else if(a<=150) {
          chet = a * 0.75 - a * 0.50;
      } else if(a<=250) {
          chet = a * 1.20 - (a * 0.75 - a * 0.50);
      } else if ( a > 250 ){
          chet  = a * 1.50 - (a * 1.20 - (a * 0.75 - a * 0.50));
      }
       chet = chet/100*120;

        System.out.println("Сумма оплаты равна: " + chet + "рупий");
      }
    public static void Exercises22(){
        System.out.print("Введите количество утят для покупи: ");
        int a = scanner.nextInt();  //количество
        int b = 250;    //цена
        if(a>=100){
            System.out.println("Цена за утят с учетом скидки  в 10% ровна: " + (a*b)/100*90);
        }

    }
    public static void Exercises23() {
        System.out.println("Введите текущий год");
        int a = scanner.nextInt();
        System.out.println("Введите год в котором сотрудник пресоединился в компанию");
        int b = scanner.nextInt();

        if (a - b >= 3) {
            System.out.println("Сотруднику выплачивается премия.");
        } else
            System.out.println("Сотрудник еще не проработал 3 года.");
    }
    public static void Exercises24(){
        System.out.print("Введите вашу зарплату: ");
        int a = scanner.nextInt();
       double HRA = 0;
        double DA = 0;
        if(a<1500) {
            HRA = a/100.0*10;
            DA = a/100.0*90;
        } else if(a >= 1500) {
            HRA = 500;
            DA = a/100.0*98;
    }
        System.out.println("HRA = " + HRA);
        System.out.println("DA = " + DA);
    }
}




