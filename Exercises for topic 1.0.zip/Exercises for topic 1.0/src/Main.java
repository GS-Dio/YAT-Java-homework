import java.util.Scanner;
//Задания Exercises 1.0
public class Main {
    public static  Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
//        Exercises1();
//        Exercises2();
//        Exercises3();
//        Exercises4();
//        Exercises5();
  //      Exercises6();
 //       Exercises7();
  //      Exercises8();
        Exercises9();
        Exercises10();
        }
        public static void Exercises1(){
            System.out.println("Здрастуйте");
            System.out.println("Бeркит Агадил");
        }
        public static void Exercises2(){
        int a = 74;
        int b = 36;
        int c = a + b;
        System.out.println(c);
    }
        public static void Exercises3(){
            int a = 50;
            int b = 3;
            int c = a / b;
            System.out.println(c);
        }
        public static void Exercises4(){
        int a = -5 + 8 * 6;
        int b = (55+9) % 9;
        int c = 20 + -3*5 / 8;
        int d = 5 + 15 / 3 * 2 - 8 % 3;
            System.out.println(a);
            System.out.println(b);
            System.out.println(c);
            System.out.println(d);
        }
        public static void Exercises5(){
            System.out.println("Введите первую цифру:");
        int a = scanner.nextInt();
            System.out.println("Введите второе цифру:");
        int b = scanner.nextInt();
        int res  = a * b;
            System.out.println("Результат умнажения: " + res);
        }
        public static void Exercises6(){
            System.out.println("Введите первую цифру:");
            int a = scanner.nextInt();
            System.out.println("Введите второе цифру:");
            int b = scanner.nextInt();
            System.out.println("Введите оператор + - / * : ");
            String с  = scanner.next();
            switch(с){
                case "+":
                    System.out.print(a+b);
                    break;
                case "-":
                    System.out.print(a-b);
                    break;
                case "*":
                    System.out.print(a*b);
                    break;
                case "/":
                    System.out.print(a/b);
                    break;
                default:
                    System.out.println("Ошибка оператора");




            }

        }
        public static void Exercises7(){
            System.out.print("Введите цифру:");
            int a = scanner.nextInt();
            for(int i=1; i<11; i++) {
                System.out.println(a + "*" + i + "=" + a*i);
            }
        }
        public static void Exercises8(){
            System.out.println("    J    a   v     v  a");
            System.out.println("    J   a a   v   v  a a");
            System.out.println("J   J  aaaaa   V V  aaaaa");
            System.out.println("  JJ  a     a   V  a     a");
        }
        public static void Exercises9(){
        double a = ((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5));
            System.out.println(a);
        }
        public static void Exercises10(){
            double a = 4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11));
            System.out.println(a);
        }
    }
