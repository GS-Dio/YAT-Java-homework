public class home29 {
    public static void main(String[] args) {
        int week = 7;
        int year = week*52;
        System.out.println(week*52 + " Дней в году");
    }
    }

