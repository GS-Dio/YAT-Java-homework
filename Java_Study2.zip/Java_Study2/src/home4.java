public class home4 {
    public static void main(String[] args) {
        int F = 24;
        int C = (F - 32)* 5/9;
        System.out.println("Цельсий равен = " + C);
    }
}
