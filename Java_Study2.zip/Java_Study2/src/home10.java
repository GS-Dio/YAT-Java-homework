public class home10 {
    public static void main(String[] args) {
        String name = "Adi ";
        String lastName = "Berkit";
        System.out.println(name + lastName);
    }
}
