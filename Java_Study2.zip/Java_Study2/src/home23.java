public class home23 {
    public static void main(String[] args) {
        int a = 123;  // переменная создана внутри метода main
    }
  //  System.out.println(a);
    // тут я попытался вызвать переменную a но поскольку
    // она локальна для метода то вне его я немогу сним взаймодействовать
}
