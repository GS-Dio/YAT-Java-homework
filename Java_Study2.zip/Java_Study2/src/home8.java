public class home8 {
    public static void main(String[] args) {
        int a = 3;
        System.out.println(++a-2);
    }
}
