public class home19 {
    public static void main(String[] args) {
       double m = 65;
        double h = 1.80;
        double IMT= m/(h*h);
        System.out.println("Индекс массы тела: " + IMT);
    }
}
