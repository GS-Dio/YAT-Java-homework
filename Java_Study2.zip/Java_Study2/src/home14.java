public class home14 {
    public static void main(String[] args) {
   int min = 480;
        System.out.println(min/60);
    }
}
