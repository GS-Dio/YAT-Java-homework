public class home6 {
    public static void main(String[] args) {
        int a = 1;
        int b = 4;
        int c = 8;

        int V = a*b*c;
        int S = 2*(a*b + b*c + a*c);

        System.out.println("Объем прямоугольного параллелепипеда: "+V);
        System.out.println("Площядь поверхности прямоугольного параллелепипедa: "+S);
    }
}
