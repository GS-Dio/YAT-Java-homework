public class home3 {
    public static void main(String[] args) {


    int l = 8;
    int w = 12;
    int P = l+w;
        System.out.println("Площадь прямоугольника равна: "+ P);
    }



    }

