public class home27 {
    public static void main(String[] args) {
        byte b = 123;
        short s = 1;
        s = b;
        System.out.println(s);
    }
}
