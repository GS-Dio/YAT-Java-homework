public class home21 {
    public static void main(String[] args) {
        int year = 19;
        System.out.println(year*365 + " дней");
    }
}
