public class home28 {
    public static void main(String[] args) {
        int a;
        int b = 132;
       // int c = b-a;
   //     System.out.println(c);
    }
}
  // По итогу из за того что у переменной "а" нету значения его пресутвие в вычеслениях вызыват ошибку
