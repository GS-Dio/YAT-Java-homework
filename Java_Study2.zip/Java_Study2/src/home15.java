public class home15 {
    public static void main(String[] args) {
        String a = "стр1 ";
        String b = "стр2 ";
        String c = "1";
        c=a; a=b; b=c;
        System.out.println("a / b: " + a + b);
    }
}
