public class home17 {
    public static void main(String[] args) {
        String a = "Добро пожаловать!!!";
        System.out.println(a.length());
    }
}
