public class home20 {
    public static void main(String[] args) {
        String a = "234";
        String b = "572";
        int i = 1;
        int i2 = 2;
        i = Integer.parseInt(a);
        i2 = Integer.parseInt(b);
        System.out.println(i + i2);
    }
}
