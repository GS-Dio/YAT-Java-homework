import java.util.Scanner;

public class IF_ELSE {
    public static void main(String[] args) {
        lesson13();
    }
    public static void Lesson1() {
        int a = 10;
        boolean b1 = a > 0;
        System.out.println(b1);
    }
    public static void Lesson2() {
        int a = 10;
        int b = 20;
        boolean b1 = a > 2 && b <= 3;

        System.out.println(b1);
    }
    public static void lesson3() {
        //  Scanner scanner = new Scanner(System.in);
        boolean b1 = false;
        boolean b2 = false;
        if (b1 || b2) {
            System.out.println("Хотя бы одно условие истенно.");
        } else {
            System.out.println("Оба условия ложны");
        }
    }
    public static void lesson4() {
        int a = 1, b = 2;
        boolean b1 = a >= 0 || b <= -2;
        System.out.println(b1);
    }
    public static void lesson5() {
        boolean b1 = true;
        boolean b2 = !b1;
        System.out.println(b2);
    }
    public static void lesson6() {
        int a = 0;

        if (a > 0) {
            System.out.println("Положительное");
        } else if (a == 0) {
            System.out.println("Ноль");
        } else if (a < 0) {
            System.out.println("Отрецательное число");
        }
    }
    public static void lesson7() {
        int a = 27;

        if (a % 2 == 0)
            System.out.println("Да оно четное");
        else
            System.out.println("Нет оно не четное");
        if (a % 10 == 7) {
            System.out.println("Чило оканчивается на 7");
        } else {
            System.out.println("Чило не оканчивается на 7");
        }
    }
    public static void lesson8() {
        int a = 28;
        if (a / 10 > a % 10) {
            System.out.println("Первая цифра больше");
        } else if (a / 10 < a % 10) {
            System.out.println("Вторая цифра больше");
        }
        if (a / 10 == a % 10) {
            System.out.println("Обе цифры равны");
        } else if (a / 10 != a % 10) {
            System.out.println("Цифры не равны");

        }
    }
    public static void lesson9() {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Напиши год, а я скажу високосный ли он: ");
        int a = scanner.nextInt();
        if(a % 4 <= 0 && a % 100 >= 0 && a % 400 <= 0) {
            System.out.println("Это високосный год");
        }
        else  {
            System.out.println("Это не високосный год");
        }

    }
    public static void lesson10(){

        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите первую цифру");
            double a = scanner.nextDouble();

        System.out.println("Введите вторую цифру");
            double b = scanner.nextDouble();

        System.out.println("Введите оператор (+,-,*,/)");
            String s = scanner.next();

            double d1 = a + b, d2 = a - b, d3 = a * b, d4 = a / b;

            if(s.equals("+")) {
                System.out.println(d1);
            }
            else if(s.equals("-")) {
                System.out.println(d2);
            }
            else if( s.equals("*")) {
                System.out.println(d3);
            }
            else if(s.equals("/")) {
                System.out.println(d4);}
            else
                System.out.println("Неверный ввод");
    }
    public static void lesson11(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите число от 60 до 100");
        int a = scanner.nextInt();
        if(a >= 90)  {
            System.out.println("A");
        }
        else if (a >= 80) {
            System.out.println("B");
        }
        else if (a >= 70) {
                System.out.println("C");
        }
        else if (a >= 60) {
            System.out.println("D");
        }
        else if(a <= 59)
            System.out.println("F");
    }
    public static void lesson12(){
        int a = 5;
        int b = 10;
        boolean b1 =  (!((a - b) == 15) && (a * 3 == 15) || (a + b == 15));
            System.out.println(b1);
    }
    public static void lesson13(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите число");
        int a = scanner.nextInt();
        String res = (a % 2 == 0) ? "Четное" : "Нечетное";
        System.out.println(res);
    }
    
}

