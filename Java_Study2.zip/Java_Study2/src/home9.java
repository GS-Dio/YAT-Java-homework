public class home9 {
    public static void main(String[] args) {
        double P = 3.14159;
        double r = 2;
        double S = P*(r*r);
        System.out.println("Площядь круга: "+S);
    }
}
