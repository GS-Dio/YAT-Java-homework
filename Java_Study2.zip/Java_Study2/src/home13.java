 public class home13 {
    public static void main(String[] args) {
        int ivan = 25;
        int vasya = 20;
        int c = 25-20;
        System.out.println("Разница в возрасте: "+ c );
    }
}
