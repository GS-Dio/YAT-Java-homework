public class home5 {
    public static void main(String[] args) {
        int a = 1;
        int b = 4;
        int c = 8;

        int d = (a + b + c) / 3; //Среднее трех чисел

        System.out.println("Среднее трех чисел: "+ d);
    }
}
