public class home30 {
    public static void main(String[] args) {
        int a = 1;
        ++a; a--;
        System.out.println(a);
    }
}
