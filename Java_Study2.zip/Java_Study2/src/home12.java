public class home12 {
    public static void main(String[] args) {
        int a = 234;
        int b = 83;
        int P = a*b/2;
        System.out.println("Площядь треугольника: "+ P) ;
    }
}
