public class home22 {
    public static void main(String[] args) {
        int a = 570;
        System.out.println("С учетом скидки в 20% сумма товара: "+ a*80/100);
    }
}
