public class Main {
    public static void main(String[] args) {
        int x = 1;
        int y = 2;

        x = y;
        y = x--;
        System.out.println(x);
        System.out.println(y);
        }
    }
