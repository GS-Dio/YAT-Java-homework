public class home31 {
    public static void main(String[] args) {

        int a = 1;
        int b = 5;
        a += 20;
        b -= 3;
        System.out.println(a);
        System.out.println(b);

        a/=7;
        b*=5;
        System.out.println(a);
        System.out.println(b);
    }
}
