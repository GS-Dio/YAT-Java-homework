public class home7 {
    public static void main(String[] args) {
        int a = 31;
        int b = 42;
        double Koren =Math.sqrt(a*b);
        System.out.println("Корень равен: " + Koren);


    }
}
