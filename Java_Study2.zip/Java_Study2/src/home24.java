public class home24 {
    public static void main(String[] args) {
      //  Описание: Объявите переменную типа float и присвойте ей значение 0.1.
        //  Затем прибавьте к ней 0.1 десять раз в цикле. Выведите результат.

        float a = 0.1F;
        for(float i=0; i<10; i++){
            a += 0.1F;
            System.out.println(a);
        }
    }
}
