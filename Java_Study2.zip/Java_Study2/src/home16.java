public class home16 {
    public static void main(String[] args) {
        int a = 4;
        int квадрат = 4*4;
        int куб = 12*a;
        System.out.println("Площядь квадрата равна: " + квадрат);
        System.out.println("Площядь куба равна: " + куб);
    }
}
