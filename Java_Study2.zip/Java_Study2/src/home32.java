public class home32 {
    public static void main(String[] args) {
        byte b1 = 120;
        short s1 = 1235;
        s1= b1;
        System.out.println(s1);
    }
}
